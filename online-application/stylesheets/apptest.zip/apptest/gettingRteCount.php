<?php 
 $school_code=$_GET['school_code'];
 $classs=$_GET['classs'];
$section=$_GET['section'];
 
 include('connection2.php');
	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
    while($row=mysql_fetch_array($sql))
	{
		
		$url=$row[0];	
		header("Location:$url/rteCountApp.php?classs=$classs&section=$section");
		
	}
	

?>