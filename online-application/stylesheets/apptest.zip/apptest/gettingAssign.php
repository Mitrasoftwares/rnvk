<?php 
 $school_code=$_GET['school_code'];
$class= $_GET['class'];
        $section = $_GET['section'];
        $subject = $_GET['subject'];
        $ass = $_GET['ass'];
	$date= $_GET['date'];
 include('connection2.php');
	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
    while($row=mysql_fetch_array($sql))
	{
		
		$url=$row[0];	
		
		header("Location:$url/assignApp.php?class=$class&section=$section&subject=$subject&ass=$ass&date=$date");
		
	}
	

?>