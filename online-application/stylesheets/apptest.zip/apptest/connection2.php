<?php
$host="localhost";
$userName="rnvk_app";
$passWord="app123";
$DataBase="rnvk_app";
$connect=mysql_connect($host,$userName,$passWord);
mysql_select_db($DataBase);


//ENTER THE RELEVANT INFO BELOW
    $mysqlUserName      = "rnvk_app";
    $mysqlPassword      = "app123";
    $mysqlHostName      = "localhost";
    $DbName             = "rnvk_app";
    $backup_name        = "mybackup.sql";
    $tables             = "";
	
	

	$mysql_host = 'localhost';
// MySQL username
$mysql_username = 'rnvk_app';
// MySQL password
$mysql_password = 'app123';
	
$servername = "localhost";
$username = "rnvk_app";
$password = "app123";
$db = "rnvk_app";

//create connection for ajax

$connect = mysqli_connect('localhost','rnvk_app','app123','rnvk_app');
if (!$connect) {
    die('Could not connect: ' . mysqli_error($connect));
}
$con=mysql_connect($mysql_host, $mysql_username, $mysql_password) or die('Error connecting to MySQL server: ' . mysql_error());

//end

// Create connection
$conn = mysqli_connect($servername, $username, $password);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$conn1 = mysqli_connect($servername, $username, $password, $db);

$con1 = mysql_connect("localhost","rnvk_app","app123");

if (!$con1) {
  die('Could not connect: ' . mysql_error());
}

mysql_select_db("rnvk_app", $con1);

try{
		$DB_con = new PDO("mysql:host={$host};dbname={$DataBase}",$userName,$passWord);
		$DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}
?>