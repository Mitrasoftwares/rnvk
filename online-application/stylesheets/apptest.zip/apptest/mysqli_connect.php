<?php
DEFINE('DB_USER','rnvk_app');
DEFINE('DB_PASSWORD','app123');
DEFINE('DB_HOST','localhost');
DEFINE('DB_NAME','rnvk_app');

$dbc=@mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME)
or die('Could not connect to mysql'.mysqli_connect_error());


?>