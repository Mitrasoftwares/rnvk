<?php 


class StudentDB{
	public $scode = "";
	public $sname = "";
	public $loginurl = "";
	public $id = "";
	public $loginPageUrl="";
	public $studentProfileUrl="";
	public $studentattendaceurl="";
	public $studentFeeUrl="";
	public $assigmentPageUrl="";
	public $circulars="";
	public $notesbyteacher="";
	public $dailytimetable ="";
	public $examtimetable ="";
	public $examgrade ="";
	public $exammarks ="";
        public $gallery ="";
        public $studentTransfeeUrl="";
        public $teacherUrl="";
	public $teacherLoginUrl="";
	public $TeacherAssignUrl="";
        public $teacherUploadImg="";
        public $teacherUploadFile="";
        public $teacherAttendance="";
        public $teacherAttenddanceGive="";
        public $teacherAttGive="";
        public $teacherExamAdd="";
        public $teacherViewExamUrl="";
        public $chatTeacher="";
        public $chatSend="";
        public $chatView="";
        public $studentChat="";
        public $studentChatView="";
        public $adminLoginUrl="";
        public $adminRegUrl="";
        public $students="";
        public $stuView="";
        public $stuAttRepo="";
        public $teacherAdmin="";
        public $teachView="";
        public $feeReport="";
        public $attConsUrl="";
        public $attDetailUrl="";
        public $smsReport="";
        public $circularApp="";
        public $sendIndividualSmsApp="";
        public $bulksms="";
        public $studentMonthFee="";
        public $app_exam="";
        public $addEvent="";
        public $updateEventApp="";
        public $deleteEventApp="";
        public $delete_img_app="";
        public $delete_assign_app="";
        public $delete_circulars_app="";
         public $leaverequest="";
        public $leaveall="";
        public $appointmentreq="";
        public $appointmentall="";
        public $assignmentImg="";
        public $install="";
        public $appointmentApp="";
        public $leaveAppTeacher="";


        

           function __construct($scode, $sname, $loginurl, $id, $loginPageUrl, $studentProfileUrl, $studentattendaceurl, $studentFeeUrl, $assigmentPageUrl, $circulars, $notesbyteacher, $dailytimetable,$examtimetable, $examgrade ,$exammarks, $gallery ,$studentTransfeeUrl,$teacherUrl,$teacherLoginUrl,$TeacherAssignUrl,$teacherUploadImg,$teacherUploadFile,$teacherAttendance ,$teacherAttenddanceGive,$teacherAttGive,$teacherExamAdd,$teacherViewExamUrl,$chatTeacher,$chatSend,$chatView,$studentChat,$studentChatView,$adminLoginUrl,$adminRegUrl,$students,$stuView,$stuAttRepo,$teacherAdmin,$teachView,$feeReport,$attConsUrl,$attDetailUrl,$smsReport,$circularApp,$sendIndividualSmsApp,$bulksms,$studentMonthFee,$app_exam,$addEvent,$updateEventApp,$deleteEventApp,$delete_img_app,$delete_assign_app,$delete_circulars_app,$leaverequest,$leaveall,$appointmentreq,$appointmentall,$assignmentImg,$install,$appointmentApp,$leaveAppTeacher){

		$this->scode= $scode;
		$this->sname= $sname;
		$this->loginurl= $loginurl;
		$this->id= $id;
		$this->loginPageUrl= $loginPageUrl;
		$this->studentProfileUrl=$studentProfileUrl;
		$this->studentattendaceurl=$studentattendaceurl;
		$this->studentFeeUrl=$studentFeeUrl;
		$this->assigmentPageUrl=$assigmentPageUrl;
		$this->circulars=$circulars;
		$this->notesbyteacher=$notesbyteacher;
		$this->dailytimetable =$dailytimetable ;
		$this->examtimetable =$examtimetable ;
                $this->examgrade = $examgrade ;
		$this->exammarks = $exammarks; 
                $this->gallery = $gallery; 
                $this->studentTransfeeUrl= $studentTransfeeUrl;
                $this->teacherUrl=$teacherUrl;
                $this->teacherLoginUrl=$teacherLoginUrl;
                $this->TeacherAssignUrl=$TeacherAssignUrl;
                $this->teacherUploadImg=$teacherUploadImg;
                $this->teacherUploadFile=$teacherUploadFile;
                $this->teacherAttendance=$teacherAttendance;
                $this->teacherAttenddanceGive=$teacherAttenddanceGive;
                $this->teacherAttGive=$teacherAttGive;
                $this->teacherExamAdd=$teacherExamAdd;
                $this->teacherViewExamUrl=$teacherViewExamUrl;
                $this->chatTeacher=$chatTeacher;
                $this->chatSend=$chatSend;
                $this->chatView=$chatView;
                $this->studentChat=$studentChat;
                $this->studentChatView=$studentChatView;
                $this->adminLoginUrl=$adminLoginUrl;
                $this->adminRegUrl=$adminRegUrl;
                $this->students=$students;
                $this->stuView=$stuView;
                $this->stuAttRepo=$stuAttRepo;
                $this->teacherAdmin=$teacherAdmin;
                $this->teachView=$teachView;
                $this->feeReport=$feeReport;
                $this->attConsUrl=$attConsUrl;
                $this->attDetailUrl=$attDetailUrl;
                $this->smsReport=$smsReport;
                $this->circularApp=$circularApp;
                $this->sendIndividualSmsApp=$sendIndividualSmsApp;
                $this->bulksms=$bulksms;
                $this->studentMonthFee=$studentMonthFee;
                $this->app_exam=$app_exam;
                $this->addEvent=$addEvent;
                $this->updateEventApp=$updateEventApp;
                $this->deleteEventApp=$deleteEventApp;
                $this->delete_img_app=$delete_img_app;
                $this->delete_assign_app=$delete_assign_app;
                $this->delete_circulars_app=$delete_circulars_app;
              $this->leaverequest=$leaverequest;
                $this->leaveall=$leaveall;
                $this->appointmentreq=$appointmentreq;
                $this->appointmentall=$appointmentall;
                $this->assignmentImg=$assignmentImg;
                $this->install=$install;
                $this->appointmentApp=$appointmentApp;
                $this->leaveAppTeacher=$leaveAppTeacher;
                
	}

}
?>