<!DOCTYPE html>
<html>
<head>
	<title>School Adding page</title>
</head>
<body>

<form action="insertSchool.php" method="post"><bR>
	<input type="text" name="name" placeholder="School Name" autofocus><bR>
	<input type="text" name="place" placeholder="Place Name"><bR>
	
	<input type="submit" ><bR>

</form>
</body>
</html>