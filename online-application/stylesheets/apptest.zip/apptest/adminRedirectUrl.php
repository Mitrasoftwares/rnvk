<?php 
 $school_code=$_GET['school_code'];
 $uname=$_GET['uname'];
 $pass=$_GET['pass'];

	include('connection2.php');
	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
    while($row=mysql_fetch_array($sql))
	{
		
		$url=$row[0];	
		header("Location:$url/json_code_admin_login.php?uname=$uname&pass=$pass");
		
	}
	

?>