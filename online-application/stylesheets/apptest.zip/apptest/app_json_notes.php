<?php

include('connection2.php');


$school_code=$_GET['school_code'];
$className=$_GET['className'];


$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
while($row=mysql_fetch_array($sql))
	{
		$url=$row[0];	
		//echo "Location:$url/multilogin_app.php?phoneNum=$phoneNum&f_name=$f_name&school_code=$school_code";
		header("Location:$url/json_code_notes.php?className=$className&school_code=$school_code");
		
	}
	
?>

