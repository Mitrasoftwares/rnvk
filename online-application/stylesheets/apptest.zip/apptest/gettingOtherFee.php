<?php
$school_code=$_GET['school_code'];
$year=$_GET['year'];
$class=$_GET['class'];
$section=$_GET['section'];

$new= str_replace(' ', '%20', $class);

include('connection2.php');
	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
while($row=mysql_fetch_array($sql))
	{
		
		$url=$row[0];	
		header("Location:$url/json_code_other_fee_repo.php?class=$new&section=$section&year=$year");
		
	}
	
?>
