<?php 
 $school_code=$_GET['school_code'];
 $id=$_GET['id'];
 $exam_type=$_GET['exam_type'];

	include('connection2.php');
	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
    while($row=mysql_fetch_array($sql))
	{
		
		$url=$row[0];	
		header("Location:$url/exam_marks_graph_app.php?school_code=$school_code&id=$id&exam_type=$exam_type");
		
	}
	

?>