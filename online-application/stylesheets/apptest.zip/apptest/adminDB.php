<?php 


class adminDB{
	public $scode = "";
	public $sname = "";
	public $loginUrl = "";
	public $id = "";
	public $loginAdminUrl="";

           function __construct($scode, $sname, $loginUrl, $id,$loginAdminUrl){

		$this->scode= $scode;
		$this->sname= $sname;
		$this->loginUrl= $loginUrl;
		$this->id= $id;
		$this->loginAdminUrl=$loginAdminUrl;
		
	}

}
?>