<?php
$school_code=$_GET['school_code'];
$date=$_GET['date'];
$head=$_GET['head'];
include('connection2.php');
$new= str_replace(' ', '%20', $head);

	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
while($row=mysql_fetch_array($sql))
	{
		
		$url=$row[0];	
		header("Location:$url/json_code_date_head.php?date=$date&head=$new");
		
	}
	
?>

