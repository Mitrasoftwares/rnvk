<?php

$schoolCodeGetting=$_GET['schoolCode'];
require_once('adminDB.php');
header('Content-Type: application/json; charset=UTF-8');


$j=0;
require_once("mysqli_connect.php");
if(mysqli_connect_errno()){
	printf("Connect Failed: %s\n", mysqli_connect_error());
	exit();
}

$query = "SELECT * FROM `adminUrl` WHERE scode =$schoolCodeGetting";
//echo $query;
$student_array = array();

if($result = $dbc->query($query)){
	while ($obj =  $result->fetch_object()) {

		
		$temp_student = new adminDB($obj->scode,$obj->sname,$obj->loginUrl,$obj->id,$obj->loginAdminUrl);

		$student_array[] = $temp_student;
		$j++;
	}



echo '{"admin":[';
for($i=0;$i<$j;$i++){
$dale_data = json_encode($student_array[$i]);
echo $dale_data;
if($i==$j-1){

}else{
echo ',';		
}

}



echo ']}';

//$result->close();
//$dbc->colse();

}
?>