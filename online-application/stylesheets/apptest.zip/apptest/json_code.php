<?php

 $schoolCodeGetting=$_GET['schoolCode'];
require_once('studentDB.php');
header('Content-Type: application/json; charset=UTF-8');


$j=0;
require_once("mysqli_connect.php");
if(mysqli_connect_errno()){
	printf("Connect Failed: %s\n", mysqli_connect_error());
	exit();
}

$query = "SELECT * FROM schoollist WHERE scode =$schoolCodeGetting";
//echo $query;
$student_array = array();

if($result = $dbc->query($query)){
	while ($obj =  $result->fetch_object()) {

		
		$temp_student = new studentDB($obj->scode,$obj->sname,$obj->loginurl,$obj->id,$obj->loginPageUrl,$obj->studentProfileUrl,$obj->studentattendaceurl,$obj->studentFeeUrl,$obj->assigmentPageUrl,$obj->circulars,$obj->notesbyteacher,$obj->dailytimetable,$obj->examtimetable,$obj->examgrade ,$obj->exammarks,$obj->gallery,$obj->studentTransfeeUrl,$obj->teacherUrl,$obj->TeacherAssignUrl,$obj->teacherLoginUrl,$obj->teacherUploadImg,$obj->teacherUploadFile,$obj->teacherAttendance,$obj->teacherAttenddanceGive,$obj->teacherAttGive,$obj->teacherExamAdd,$obj->teacherViewExamUrl,$obj->chatTeacher,$obj->chatSend,$obj->chatView,$obj->studentChat,$obj->studentChatView,$obj->adminLoginUrl,$obj->adminRegUrl,$obj->students,$obj->stuView,$obj->stuAttRepo,$obj->teacherAdmin,$obj->teachView,$obj->feeReport,$obj->attConsUrl,$obj->attDetailUrl,$obj->smsReport,$obj->circularApp,$obj->sendIndividualSmsApp,$obj->bulksms,$obj->studentMonthFee,$obj->app_exam,$obj->addEvent,$obj->updateEventApp,$obj->deleteEventApp,$obj->delete_img_app,$obj->delete_assign_app,$obj->delete_circulars_app,$obj->leaverequest,$obj->leaveall,$obj->appointmentreq,$obj->appointmentall,$obj->assignmentImg,$obj->install,$obj->appointmentApp,$obj->leaveAppTeacher);

		$student_array[] = $temp_student;
		$j++;
	}



echo '{"school":[';
for($i=0;$i<$j;$i++){
$dale_data = json_encode($student_array[$i]);
echo $dale_data;
if($i==$j-1){

}else{
echo ',';		
}

}



echo ']}';

//$result->close();
//$dbc->colse();

}
?>