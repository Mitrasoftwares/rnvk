-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 30, 2017 at 07:58 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `schoolapp`
--
CREATE DATABASE IF NOT EXISTS `schoolapp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `schoolapp`;

-- --------------------------------------------------------

--
-- Table structure for table `schoolname`
--

CREATE TABLE IF NOT EXISTS `schoolname` (
  `name` varchar(100) NOT NULL,
  `place` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `schoolname`
--

INSERT INTO `schoolname` (`name`, `place`, `id`) VALUES
('SAVS hirisave', 'Hirisave', 6),
('Gokula Academy', 'Academy', 7),
('Vishwavijaya Vidya Shale', 'Sagara', 8),
('New Alience College', 'Bhadravathi', 9),
('Shalini Vidya Shale', 'Tumkuru', 10),
('SVG institution', 'Rajaji Nagar', 11),
('PES Turvekere', 'Turvekere', 12),
('KPS Hirisave', 'Hirisave', 13),
('Rachana Public School', 'Shimoga', 14),
('Deshpade', 'shimoga', 15);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
