<?php 
 $school_code=$_GET['school_code'];
 $teachid=$_GET['teachid'];

	include('mysqli_connect.php');
	$sql=mysqli_query($dbc,"SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
    while($row=mysqli_fetch_array($sql))
	{
		
		$url=$row[0];	
		header("Location:$url/json_code_teacherassign.php?teachid=$teachid");
		
	}
	

?>