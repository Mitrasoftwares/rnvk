<?php


$schoolName = $_POST['name'];
$placeName = $_POST['place'];


echo "$schoolName<br>
$placeName";


$data_missing=array();

require_once("mysqli_connect.php");

	//$query="INSERT INTO domasticvehiclebook(cusname,addr,city,post,phone,predate,pretime,booktime,id) VALUES(?,?,?,?,?,?,?,NOW(),NULL)";
	$query="INSERT INTO schoolname(name, place, id) VALUES(?,?,NULL)";
	echo $query;
	$stmt=mysqli_prepare($dbc,$query);
	mysqli_stmt_bind_param($stmt,"ss",$schoolName ,$placeName);
	mysqli_stmt_execute($stmt);
	$affected_rows=mysqli_stmt_affected_rows($stmt);
	if($affected_rows==1){
		echo 'School Added Successfully';
	
		mysqli_stmt_close($stmt);
		mysqli_close($dbc);
	}
	else{
		echo "Error Occured <br />";
		echo mysqli_error();
	mysqli_stmt_close($stmt);
		mysqli_close($dbc);	
	}

header("location:index.php");
?>
</body>
</html>


