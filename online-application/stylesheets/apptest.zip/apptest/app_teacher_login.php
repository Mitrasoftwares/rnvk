<?php

include('connection2.php');


$school_code=$_GET['school_code'];
$t_fname=$_GET['t_fname'];
$t_mobile=$_GET['t_mobile'];
$t_password=$_GET['t_password'];	


	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
while($row=mysql_fetch_array($sql))
	{
		$url=$row[0];	
		//echo "Location:$url/multilogin_app.php?phone=$phone&fname=$fname&school_code=$school_code&password=$password";
		header("Location:$url/teacher_login_app.php?t_fname=$t_fname&t_mobile=$t_mobile&t_password=$t_password&school_code=$school_code");
		
	}
	
?>
