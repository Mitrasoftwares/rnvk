<?php
try{
	$handler=new PDO('mysql:host=localhost;dbname=campupxl_app','campupxl_app','campus123');
	$handler->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(Exception $e)
{
	die();
	}
	$query=$handler->query('SELECT `scode`,`sname` FROM `schoollist`');
	$records=array();
	$records=$query->fetchAll(PDO::FETCH_ASSOC);
	$json['entry']= $records;
	echo json_encode($json);
?>