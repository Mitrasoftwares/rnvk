<?php
$school_code=$_GET['school_code'];
$start_date=$_GET['start_date'];
$end_date=$_GET['end_date'];

include('connection2.php');

	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
     while($row=mysql_fetch_array($sql))
	{
		
		$url=$row[0];	
		header("Location:$url/date_wise_tot_app.php?start_date=$start_date&end_date=$end_date");
		
	}
	
?>

