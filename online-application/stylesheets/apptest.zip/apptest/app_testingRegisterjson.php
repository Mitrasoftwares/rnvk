<?php

include('connection2.php');


$school_code=$_GET['school_code'];

$phoneNum=$_GET['phoneNum'];

$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
while($row=mysql_fetch_array($sql))
	{
		$url=$row[0];	
		//echo "Location:$url/multilogin_app.php?phoneNum=$phoneNum&f_name=$f_name&school_code=$school_code";
		header("Location:$url/testingRegisterjson.php?phoneNum=$phoneNum");
		
	}
	
?>

