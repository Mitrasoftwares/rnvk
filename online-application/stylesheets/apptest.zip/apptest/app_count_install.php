<?php
include 'mysqli_connect.php';
$school_code=$_GET['school_code'];
$classs=$_GET['classs'];
$section=$_GET['section'];

$new= str_replace(' ', '%20', $classs);

	$sql=mysqli_query($dbc,"SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
while($row=mysqli_fetch_array($sql))
	{
		
		$url=$row[0];	
		header("Location:$url/count_of_install.php?classs=$new&section=$section");
		
	}
	
?>

