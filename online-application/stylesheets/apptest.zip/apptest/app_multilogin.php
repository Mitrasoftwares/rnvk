<?php

include('connection2.php');


$school_code=$_GET['school_code'];
$g_fname=$_GET['g_fname'];
$mobile=$_GET['mobile'];
 $password=$_GET['password'];
	


	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
while($row=mysql_fetch_array($sql))
	{
		$url=$row[0];	
		//echo "Location:$url/multilogin_app.php?phone=$phone&fname=$fname&school_code=$school_code&password=$password";
		header("Location:$url/multilogin_app.php?mobile=$mobile&password=$password&g_fname=$g_fname&school_code=$school_code");
		
	}
	
?>

