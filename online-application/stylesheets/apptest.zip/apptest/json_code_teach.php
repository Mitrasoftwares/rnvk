<?php

$t_fname = $_GET['t_fname'];
$t_password = $_GET['t_password'];

require_once('teacherDB.php');

header('Content-Type: application/json; charse=UTF-8');

 //$irshad = new Student("Irshad","Kautilya Shimoga","Shimoga","Karnataka","9035818785","12/2/2017","Male","12/12/2016","Chanakya","12");



//echo "password  = ".$password;
$j=0;

require_once("mysqli_connect.php");
if(mysqli_connect_errno()){
	printf("Connect Failed: %s\n", mysqli_connect_error());
	exit();
}

$query = "SELECT * FROM teachers where t_fname='$t_fname' AND t_password='$t_password'";
//echo $query;

$student_array = array();

if($result = $dbc->query($query)){
	while ($obj =  $result->fetch_object()) {

		/*printf("%s %s %s %s %s %s %s %s %s %s %s <br>",

			$obj->name,$obj->addr,$obj->city,$obj->state,$obj->mob,$obj->admit,$obj->helth,$obj->gen,$obj->dob,$obj->rphysician,$obj->id);
*/
		$temp_student = new teacherDB($obj->id,$obj->t_fname,$obj->t_password);

		$student_array[] = $temp_student;
		$j++;
	}

//echo "<br /><br />";

echo '{"teachers":[';
if($j>0){
$dale_data = json_encode($student_array[0]);

echo $dale_data;
}else{
	

}
//echo ',<br />';
echo ']}';

//$result->close();
//$dbc->colse();

}
?>