<?php 
 $school_code=$_GET['school_code'];
 $teachid=$_GET['teachid'];
  $class=$_GET['class'];
 $section=$_GET['section'];
 $sem=$_GET['sem'];
$new= str_replace(' ', '%20', $class);
$new1= str_replace(' ', '%20', $sem);
	include('mysqli_connect.php');
	$sql=mysqli_query($dbc,"SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
    while($row=mysqli_fetch_array($sql))
	{
		
		$url=$row[0];	
		header("Location:$url/gettingSubject.php?teachid=$teachid&class=$new&section=$section&sem=$new1");
		
	}
	

?>