<?php

include('connection2.php');


$school_code=$_GET['school_code'];
$uname=$_GET['uname'];
$pass=$_GET['pass'];

	


	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
while($row=mysql_fetch_array($sql))
	{
		$url=$row[0];	
		//echo "Location:$url/multilogin_app.php?phone=$phone&fname=$fname&school_code=$school_code&password=$password";
		header("Location:$url/admin_login_app.php?uname=$uname&pass=$pass&school_code=$school_code");
		
	}
	
?>

