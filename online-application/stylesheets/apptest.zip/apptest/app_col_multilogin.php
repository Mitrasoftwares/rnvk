<?php

include('connection2.php');


$college_code=$_GET['college_code'];
$f_name=$_GET['f_name'];
$phone=$_GET['phone'];
 $c_password=$_GET['c_password'];
	


	$sql=mysql_query("SELECT `url` FROM `schoollist` WHERE `scode`='$school_code'");
while($row=mysql_fetch_array($sql))
	{
		$url=$row[0];	
		//echo "Location:$url/multilogin_app.php?phone=$phone&fname=$fname&school_code=$school_code&password=$password";
		header("Location:$url/multilogin_app_col.php?phone=$phone&c_password=$c_password&f_name=$f_name&college_code=$college_code");
		
	}
	
?>

